const router = require('express').Router();
const { body, param, query } = require('express-validator');
const validate = require('../middleware/validate');
const { protect } = require('../middleware/auth');
const { STATUSES, PRIORITIES } = require('../models/Task');
const c = require('../controllers/taskController');

const idRule = param('id').isMongoId().withMessage('Invalid task id');

const createRules = [
  body('title').trim().notEmpty().withMessage('Title is required').isLength({ max: 120 }).withMessage('Title max 120 chars'),
  body('description').optional().isString().isLength({ max: 1000 }).withMessage('Description max 1000 chars'),
  body('priority').optional().isIn(PRIORITIES).withMessage(`Priority must be one of: ${PRIORITIES.join(', ')}`),
  body('dueDate').optional({ nullable: true, checkFalsy: true }).isISO8601().withMessage('dueDate must be a valid date'),
];

const updateRules = [
  idRule,
  body('title').optional().trim().notEmpty().withMessage('Title cannot be empty').isLength({ max: 120 }),
  body('description').optional().isString().isLength({ max: 1000 }),
  body('priority').optional().isIn(PRIORITIES).withMessage(`Priority must be one of: ${PRIORITIES.join(', ')}`),
  body('status').optional().isIn(STATUSES).withMessage(`Status must be one of: ${STATUSES.join(', ')}`),
  body('dueDate').optional({ nullable: true, checkFalsy: true }).isISO8601().withMessage('dueDate must be a valid date'),
];

const listRules = [
  query('page').optional().isInt({ min: 1 }).withMessage('page must be >= 1'),
  query('limit').optional().isInt({ min: 1, max: 50 }).withMessage('limit must be 1-50'),
  query('status').optional({ checkFalsy: true }).isIn(STATUSES).withMessage('Invalid status filter'),
  query('priority').optional({ checkFalsy: true }).isIn(PRIORITIES).withMessage('Invalid priority filter'),
  query('order').optional().isIn(['asc', 'desc']).withMessage('order must be asc or desc'),
];

router.use(protect);

router.get('/stats', c.getStats);
router.route('/').get(listRules, validate, c.getTasks).post(createRules, validate, c.createTask);
router
  .route('/:id')
  .get(idRule, validate, c.getTask)
  .put(updateRules, validate, c.updateTask)
  .delete(idRule, validate, c.deleteTask);
router.patch(
  '/:id/status',
  [idRule, body('status').isIn(STATUSES).withMessage(`Status must be one of: ${STATUSES.join(', ')}`)],
  validate,
  c.updateStatus
);

module.exports = router;
