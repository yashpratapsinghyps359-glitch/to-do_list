const AppError = require('../utils/AppError');

exports.notFound = (req, res, next) => {
  next(new AppError(`Route not found: ${req.method} ${req.originalUrl}`, 404));
};

exports.errorHandler = (err, req, res, next) => { // eslint-disable-line no-unused-vars
  let error = err;

  if (err.name === 'ValidationError' && err.errors) {
    const errors = Object.values(err.errors).map((e) => ({ field: e.path, message: e.message }));
    error = new AppError('Validation failed', 400, errors);
  } else if (err.name === 'CastError') {
    error = new AppError(`Invalid ${err.path}: ${err.value}`, 400);
  } else if (err.code === 11000) {
    const field = Object.keys(err.keyValue || {})[0] || 'field';
    error = new AppError(`${field} already exists`, 409, [{ field, message: `${field} already exists` }]);
  } else if (err.name === 'JsonWebTokenError') {
    error = new AppError('Invalid token. Please log in again.', 401);
  } else if (err.name === 'TokenExpiredError') {
    error = new AppError('Token expired. Please log in again.', 401);
  }

  const status = error.statusCode || 500;
  if (status === 500) console.error(err);

  res.status(status).json({
    success: false,
    message: error.isOperational ? error.message : 'Internal server error',
    ...(error.errors && { errors: error.errors }),
    ...(process.env.NODE_ENV !== 'production' && status === 500 && { stack: err.stack }),
  });
};
