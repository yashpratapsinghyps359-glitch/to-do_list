const jwt = require('jsonwebtoken');
const User = require('../models/User');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');

exports.protect = asyncHandler(async (req, res, next) => {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.split(' ')[1] : null;
  if (!token) throw new AppError('Not authenticated. Please log in.', 401);

  const decoded = jwt.verify(token, process.env.JWT_SECRET); // errors handled globally
  const user = await User.findById(decoded.id);
  if (!user) throw new AppError('User no longer exists.', 401);

  req.user = user;
  next();
});
