const jwt = require('jsonwebtoken');
const User = require('../models/User');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');

const signToken = (id) =>
  jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '7d' });

const sendAuth = (res, user, statusCode) => {
  res.status(statusCode).json({
    success: true,
    token: signToken(user._id),
    user: { id: user._id, name: user.name, email: user.email },
  });
};

exports.register = asyncHandler(async (req, res) => {
  const { name, email, password } = req.body;
  const exists = await User.findOne({ email });
  if (exists) throw new AppError('Email already registered', 409, [{ field: 'email', message: 'Email already registered' }]);
  const user = await User.create({ name, email, password });
  sendAuth(res, user, 201);
});

exports.login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email }).select('+password');
  if (!user || !(await user.comparePassword(password))) {
    throw new AppError('Invalid email or password', 401);
  }
  sendAuth(res, user, 200);
});

exports.me = asyncHandler(async (req, res) => {
  const { _id, name, email } = req.user;
  res.json({ success: true, user: { id: _id, name, email } });
});
