const mongoose = require('mongoose');
const Task = require('../models/Task');
const { TRANSITIONS } = Task;
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');

const SORT_FIELDS = ['createdAt', 'updatedAt', 'dueDate', 'title', 'priority', 'status'];
const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

const findOwnTask = async (id, userId) => {
  const task = await Task.findOne({ _id: id, user: userId });
  if (!task) throw new AppError('Task not found', 404);
  return task;
};

const applyStatus = (task, next) => {
  if (next === task.status) return;
  if (!TRANSITIONS[task.status].includes(next)) {
    throw new AppError(
      `Invalid status transition: ${task.status} -> ${next}. Allowed: ${TRANSITIONS[task.status].join(', ')}`,
      400
    );
  }
  task.status = next;
  task.completedAt = next === 'completed' ? new Date() : null;
};

// GET /api/tasks?page=1&limit=10&status=&priority=&search=&sortBy=createdAt&order=desc
exports.getTasks = asyncHandler(async (req, res) => {
  const { status, priority, search, sortBy = 'createdAt', order = 'desc' } = req.query;
  const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
  const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 10, 1), 50);

  const filter = { user: req.user._id };
  if (status) filter.status = status;
  if (priority) filter.priority = priority;
  if (search) filter.title = { $regex: escapeRegex(search), $options: 'i' };

  const sortField = SORT_FIELDS.includes(sortBy) ? sortBy : 'createdAt';
  const sort = { [sortField]: order === 'asc' ? 1 : -1, _id: -1 };

  const [tasks, total] = await Promise.all([
    Task.find(filter).sort(sort).skip((page - 1) * limit).limit(limit),
    Task.countDocuments(filter),
  ]);

  res.json({
    success: true,
    data: tasks,
    pagination: { page, limit, total, pages: Math.max(Math.ceil(total / limit), 1) },
  });
});

// GET /api/tasks/stats
exports.getStats = asyncHandler(async (req, res) => {
  const rows = await Task.aggregate([
    { $match: { user: new mongoose.Types.ObjectId(req.user._id) } },
    { $group: { _id: '$status', count: { $sum: 1 } } },
  ]);
  const stats = { pending: 0, 'in-progress': 0, completed: 0, total: 0 };
  rows.forEach((r) => { stats[r._id] = r.count; stats.total += r.count; });
  res.json({ success: true, data: stats });
});

exports.getTask = asyncHandler(async (req, res) => {
  const task = await findOwnTask(req.params.id, req.user._id);
  res.json({ success: true, data: task });
});

exports.createTask = asyncHandler(async (req, res) => {
  const { title, description, priority, dueDate } = req.body;
  const task = await Task.create({ title, description, priority, dueDate: dueDate || null, user: req.user._id });
  res.status(201).json({ success: true, data: task });
});

exports.updateTask = asyncHandler(async (req, res) => {
  const task = await findOwnTask(req.params.id, req.user._id);
  const { title, description, priority, dueDate, status } = req.body;

  if (title !== undefined) task.title = title;
  if (description !== undefined) task.description = description;
  if (priority !== undefined) task.priority = priority;
  if (dueDate !== undefined) task.dueDate = dueDate || null;
  if (status !== undefined) applyStatus(task, status);

  await task.save();
  res.json({ success: true, data: task });
});

exports.updateStatus = asyncHandler(async (req, res) => {
  const task = await findOwnTask(req.params.id, req.user._id);
  applyStatus(task, req.body.status);
  await task.save();
  res.json({ success: true, data: task });
});

exports.deleteTask = asyncHandler(async (req, res) => {
  const task = await findOwnTask(req.params.id, req.user._id);
  await task.deleteOne();
  res.json({ success: true, message: 'Task deleted' });
});
