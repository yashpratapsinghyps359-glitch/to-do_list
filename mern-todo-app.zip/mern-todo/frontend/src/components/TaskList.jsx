import TaskItem from './TaskItem.jsx';

export default function TaskList({ tasks, loading, ...handlers }) {
  if (loading && tasks.length === 0) return <p className="center muted">Loading tasks...</p>;
  if (tasks.length === 0) return <p className="center muted">No tasks found. Create your first one!</p>;
  return (
    <ul className={`task-list ${loading ? 'dim' : ''}`}>
      {tasks.map((t) => <TaskItem key={t._id} task={t} {...handlers} />)}
    </ul>
  );
}
