const items = [
  ['total', 'Total'],
  ['pending', 'Pending'],
  ['in-progress', 'In Progress'],
  ['completed', 'Completed'],
];

export default function StatsBar({ stats, active, onSelect }) {
  return (
    <div className="stats">
      {items.map(([key, label]) => {
        const value = key === 'total' ? '' : key;
        return (
          <button
            key={key}
            className={`stat ${active === value ? 'stat-active' : ''}`}
            onClick={() => onSelect(value)}
          >
            <strong>{stats[key] ?? 0}</strong>
            <span>{label}</span>
          </button>
        );
      })}
    </div>
  );
}
