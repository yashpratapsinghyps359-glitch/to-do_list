import { useState } from 'react';

// Mirrors the backend workflow.
const NEXT = {
  pending: [['in-progress', 'Start'], ['completed', 'Complete']],
  'in-progress': [['pending', 'Back to Pending'], ['completed', 'Complete']],
  completed: [['in-progress', 'Reopen']],
};
const LABEL = { pending: 'Pending', 'in-progress': 'In Progress', completed: 'Completed' };

export default function TaskItem({ task, onStatus, onEdit, onDelete }) {
  const [busy, setBusy] = useState(false);
  const overdue = task.dueDate && task.status !== 'completed' && new Date(task.dueDate) < new Date();

  const run = async (fn) => {
    setBusy(true);
    try { await fn(); } finally { setBusy(false); }
  };

  return (
    <li className={`card task ${task.status === 'completed' ? 'task-done' : ''}`}>
      <div className="task-head">
        <h4>{task.title}</h4>
        <div className="badges">
          <span className={`badge badge-${task.status}`}>{LABEL[task.status]}</span>
          <span className={`badge priority-${task.priority}`}>{task.priority}</span>
        </div>
      </div>
      {task.description && <p className="muted">{task.description}</p>}
      {task.dueDate && (
        <small className={overdue ? 'error-text' : 'muted'}>
          Due {new Date(task.dueDate).toLocaleDateString()} {overdue && '· Overdue'}
        </small>
      )}
      <div className="actions">
        {NEXT[task.status].map(([status, label]) => (
          <button key={status} className="btn btn-small" disabled={busy} onClick={() => run(() => onStatus(task._id, status))}>
            {label}
          </button>
        ))}
        <button className="btn btn-small btn-ghost" onClick={() => onEdit(task)}>Edit</button>
        <button
          className="btn btn-small btn-danger"
          disabled={busy}
          onClick={() => window.confirm('Delete this task?') && run(() => onDelete(task._id))}
        >
          Delete
        </button>
      </div>
    </li>
  );
}
