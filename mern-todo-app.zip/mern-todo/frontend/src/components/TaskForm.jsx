import { useState } from 'react';
import FormField from './FormField.jsx';
import Alert from './Alert.jsx';
import { parseError } from '../api/client.js';

const toDateInput = (d) => (d ? new Date(d).toISOString().slice(0, 10) : '');

// Reusable for both create and edit.
export default function TaskForm({ initial, onSubmit, onCancel }) {
  const [form, setForm] = useState({
    title: initial?.title || '',
    description: initial?.description || '',
    priority: initial?.priority || 'medium',
    dueDate: toDateInput(initial?.dueDate),
  });
  const [errors, setErrors] = useState({});
  const [serverError, setServerError] = useState('');
  const [saving, setSaving] = useState(false);

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    const clientErrors = {};
    if (!form.title.trim()) clientErrors.title = 'Title is required';
    if (form.title.length > 120) clientErrors.title = 'Title max 120 characters';
    setErrors(clientErrors);
    if (Object.keys(clientErrors).length) return;

    setSaving(true);
    setServerError('');
    try {
      await onSubmit({ ...form, dueDate: form.dueDate || null });
    } catch (err) {
      const parsed = parseError(err);
      setErrors(parsed.fieldErrors);
      setServerError(parsed.message);
      setSaving(false);
    }
  };

  return (
    <form className="card form" onSubmit={handleSubmit} noValidate>
      <h3>{initial ? 'Edit task' : 'New task'}</h3>
      <Alert>{serverError}</Alert>
      <FormField label="Title" error={errors.title}>
        <input value={form.title} onChange={set('title')} maxLength={130} autoFocus />
      </FormField>
      <FormField label="Description" error={errors.description}>
        <textarea rows={3} value={form.description} onChange={set('description')} />
      </FormField>
      <div className="row">
        <FormField label="Priority" error={errors.priority}>
          <select value={form.priority} onChange={set('priority')}>
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
          </select>
        </FormField>
        <FormField label="Due date" error={errors.dueDate}>
          <input type="date" value={form.dueDate} onChange={set('dueDate')} />
        </FormField>
      </div>
      <div className="actions">
        <button type="button" className="btn btn-ghost" onClick={onCancel}>Cancel</button>
        <button className="btn" disabled={saving}>{saving ? 'Saving...' : 'Save'}</button>
      </div>
    </form>
  );
}
