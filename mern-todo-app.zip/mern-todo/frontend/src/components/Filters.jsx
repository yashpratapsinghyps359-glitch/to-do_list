import { useEffect, useState } from 'react';
import useDebounce from '../hooks/useDebounce.js';

export default function Filters({ params, onChange }) {
  const [search, setSearch] = useState(params.search);
  const debounced = useDebounce(search, 400);

  useEffect(() => {
    if (debounced !== params.search) onChange({ search: debounced });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debounced]);

  return (
    <div className="filters">
      <input
        type="search"
        placeholder="Search by title..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />
      <select value={params.status} onChange={(e) => onChange({ status: e.target.value })}>
        <option value="">All statuses</option>
        <option value="pending">Pending</option>
        <option value="in-progress">In Progress</option>
        <option value="completed">Completed</option>
      </select>
      <select value={params.priority} onChange={(e) => onChange({ priority: e.target.value })}>
        <option value="">All priorities</option>
        <option value="low">Low</option>
        <option value="medium">Medium</option>
        <option value="high">High</option>
      </select>
      <select value={params.sortBy} onChange={(e) => onChange({ sortBy: e.target.value })}>
        <option value="createdAt">Sort: Created</option>
        <option value="dueDate">Sort: Due date</option>
        <option value="title">Sort: Title</option>
        <option value="priority">Sort: Priority</option>
        <option value="status">Sort: Status</option>
      </select>
      <button
        className="btn btn-ghost"
        onClick={() => onChange({ order: params.order === 'asc' ? 'desc' : 'asc' })}
        title="Toggle sort order"
      >
        {params.order === 'asc' ? '↑ Asc' : '↓ Desc'}
      </button>
    </div>
  );
}
