import { useCallback, useEffect, useState } from 'react';
import api, { parseError } from '../api/client.js';

const DEFAULT_PARAMS = { page: 1, limit: 6, status: '', priority: '', search: '', sortBy: 'createdAt', order: 'desc' };

export default function useTasks() {
  const [tasks, setTasks] = useState([]);
  const [stats, setStats] = useState({ pending: 0, 'in-progress': 0, completed: 0, total: 0 });
  const [pagination, setPagination] = useState({ page: 1, pages: 1, total: 0, limit: DEFAULT_PARAMS.limit });
  const [params, setParams] = useState(DEFAULT_PARAMS);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const fetchStats = useCallback(async () => {
    try {
      const res = await api.get('/tasks/stats');
      setStats(res.data.data);
    } catch { /* non-critical */ }
  }, []);

  const fetchTasks = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const clean = Object.fromEntries(Object.entries(params).filter(([, v]) => v !== ''));
      const res = await api.get('/tasks', { params: clean });
      setTasks(res.data.data);
      setPagination(res.data.pagination);
      // If current page is beyond last page (e.g. after deleting), step back.
      if (res.data.data.length === 0 && params.page > 1) {
        setParams((p) => ({ ...p, page: Math.max(res.data.pagination.pages, 1) }));
      }
    } catch (err) {
      setError(parseError(err).message);
    } finally {
      setLoading(false);
    }
  }, [params]);

  useEffect(() => { fetchTasks(); }, [fetchTasks]);
  useEffect(() => { fetchStats(); }, [fetchStats]);

  // Changing any filter resets to page 1
  const updateParams = useCallback((patch) => {
    setParams((p) => ({ ...p, ...patch, page: patch.page ?? 1 }));
  }, []);

  const refresh = useCallback(() => Promise.all([fetchTasks(), fetchStats()]), [fetchTasks, fetchStats]);

  const createTask = async (payload) => { await api.post('/tasks', payload); await refresh(); };
  const updateTask = async (id, payload) => { await api.put(`/tasks/${id}`, payload); await refresh(); };
  const changeStatus = async (id, status) => { await api.patch(`/tasks/${id}/status`, { status }); await refresh(); };
  const deleteTask = async (id) => { await api.delete(`/tasks/${id}`); await refresh(); };

  return {
    tasks, stats, pagination, params, loading, error,
    updateParams, createTask, updateTask, changeStatus, deleteTask,
  };
}
