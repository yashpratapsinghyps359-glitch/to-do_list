import { useState } from 'react';
import { Link, Navigate, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import { parseError } from '../api/client.js';
import FormField from '../components/FormField.jsx';
import Alert from '../components/Alert.jsx';

export default function Register() {
  const { user, register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [errors, setErrors] = useState({});
  const [serverError, setServerError] = useState('');
  const [loading, setLoading] = useState(false);

  if (user) return <Navigate to="/" replace />;

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setServerError('');
    setErrors({});
    try {
      await register(form);
      navigate('/');
    } catch (err) {
      const p = parseError(err);
      setErrors(p.fieldErrors);
      setServerError(p.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <form className="card form auth" onSubmit={submit} noValidate>
      <h2>Create account</h2>
      <Alert>{serverError}</Alert>
      <FormField label="Name" error={errors.name}>
        <input value={form.name} onChange={set('name')} />
      </FormField>
      <FormField label="Email" error={errors.email}>
        <input type="email" value={form.email} onChange={set('email')} />
      </FormField>
      <FormField label="Password (min 6 chars)" error={errors.password}>
        <input type="password" value={form.password} onChange={set('password')} />
      </FormField>
      <button className="btn" disabled={loading}>{loading ? 'Creating...' : 'Register'}</button>
      <p className="muted">Already registered? <Link to="/login">Login</Link></p>
    </form>
  );
}
