import { useState } from 'react';
import useTasks from '../hooks/useTasks.js';
import StatsBar from '../components/StatsBar.jsx';
import Filters from '../components/Filters.jsx';
import TaskForm from '../components/TaskForm.jsx';
import TaskList from '../components/TaskList.jsx';
import Pagination from '../components/Pagination.jsx';
import Alert from '../components/Alert.jsx';
import { parseError } from '../api/client.js';

export default function Dashboard() {
  const t = useTasks();
  const [editing, setEditing] = useState(null); // null | 'new' | task
  const [actionError, setActionError] = useState('');

  const guard = (fn) => async (...args) => {
    setActionError('');
    try { await fn(...args); } catch (err) { setActionError(parseError(err).message); }
  };

  const handleSubmit = async (payload) => {
    if (editing === 'new') await t.createTask(payload);
    else await t.updateTask(editing._id, payload);
    setEditing(null);
  };

  return (
    <section>
      <div className="page-head">
        <h2>My Tasks</h2>
        <button className="btn" onClick={() => setEditing('new')}>+ Add task</button>
      </div>

      <StatsBar stats={t.stats} active={t.params.status} onSelect={(status) => t.updateParams({ status })} />
      <Filters params={t.params} onChange={t.updateParams} />

      <Alert>{t.error || actionError}</Alert>

      {editing && (
        <TaskForm
          key={editing === 'new' ? 'new' : editing._id}
          initial={editing === 'new' ? null : editing}
          onSubmit={handleSubmit}
          onCancel={() => setEditing(null)}
        />
      )}

      <TaskList
        tasks={t.tasks}
        loading={t.loading}
        onStatus={guard(t.changeStatus)}
        onDelete={guard(t.deleteTask)}
        onEdit={setEditing}
      />
      <Pagination pagination={t.pagination} onPage={(page) => t.updateParams({ page })} />
    </section>
  );
}
