import { useState } from 'react';
import { Link, Navigate, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import { parseError } from '../api/client.js';
import FormField from '../components/FormField.jsx';
import Alert from '../components/Alert.jsx';

export default function Login() {
  const { user, login } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: '', password: '' });
  const [errors, setErrors] = useState({});
  const [serverError, setServerError] = useState('');
  const [loading, setLoading] = useState(false);

  if (user) return <Navigate to="/" replace />;

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setServerError('');
    setErrors({});
    try {
      await login(form);
      navigate('/');
    } catch (err) {
      const p = parseError(err);
      setErrors(p.fieldErrors);
      setServerError(p.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <form className="card form auth" onSubmit={submit} noValidate>
      <h2>Login</h2>
      <Alert>{serverError}</Alert>
      <FormField label="Email" error={errors.email}>
        <input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
      </FormField>
      <FormField label="Password" error={errors.password}>
        <input type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
      </FormField>
      <button className="btn" disabled={loading}>{loading ? 'Logging in...' : 'Login'}</button>
      <p className="muted">No account? <Link to="/register">Register</Link></p>
    </form>
  );
}
