# MERN To-Do Application

Full-stack task manager: **React (Vite) + Node/Express + MongoDB**, JWT auth.

## Features
- Full CRUD for tasks via REST API (each user sees only their own tasks)
- Status workflow: `pending ⇄ in-progress → completed` (invalid transitions are rejected with 400)
- Server-side validation (express-validator + Mongoose) and one structured error format
- Pagination, filtering (status, priority, title search), sorting (field + asc/desc)
- JWT authentication (register / login / me), bcrypt password hashing
- Dashboard stats, reusable React components, custom hooks (`useTasks`, `useDebounce`), auth context

## Project structure
```
backend/src
  config/db.js            MongoDB connection
  models/                 User, Task (schemas + workflow rules)
  controllers/            authController, taskController (business logic)
  routes/                 authRoutes, taskRoutes (routing + validation rules)
  middleware/             auth (JWT), validate, errorHandler
  utils/                  AppError, asyncHandler
  app.js / server.js      Express app / entrypoint
frontend/src
  api/client.js           axios instance, token handling, error parsing
  context/AuthContext.jsx
  hooks/                  useTasks, useDebounce
  components/             TaskForm, TaskItem, TaskList, Filters, Pagination, StatsBar...
  pages/                  Login, Register, Dashboard
```

## Prerequisites
Node.js 18+ and MongoDB (local install, MongoDB Atlas, or `docker compose up -d` using the included file).

## Run it
```bash
# 1. Backend
cd backend
npm install
cp .env.example .env        # already provided; edit MONGO_URI / JWT_SECRET if needed
npm run dev                 # http://localhost:5000

# 2. Frontend (new terminal)
cd frontend
npm install
npm run dev                 # http://localhost:5173  (proxies /api to :5000)
```
Open http://localhost:5173, register an account, and start adding tasks.

## API reference
All `/api/tasks` routes need `Authorization: Bearer <token>`.

| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/auth/register` | `{name, email, password}` → `{token, user}` |
| POST | `/api/auth/login` | `{email, password}` → `{token, user}` |
| GET | `/api/auth/me` | Current user |
| GET | `/api/tasks` | List. Query: `page, limit(≤50), status, priority, search, sortBy, order` |
| GET | `/api/tasks/stats` | Counts per status |
| POST | `/api/tasks` | `{title, description?, priority?, dueDate?}` |
| GET | `/api/tasks/:id` | Single task |
| PUT | `/api/tasks/:id` | Update fields (and optionally `status`) |
| PATCH | `/api/tasks/:id/status` | `{status}` – enforces workflow |
| DELETE | `/api/tasks/:id` | Delete |

`sortBy`: `createdAt | updatedAt | dueDate | title | priority | status`, `order`: `asc | desc`.

### Response shapes
```json
{ "success": true, "data": [...], "pagination": { "page": 1, "limit": 10, "total": 25, "pages": 3 } }
{ "success": false, "message": "Validation failed", "errors": [{ "field": "title", "message": "Title is required" }] }
```

## Environment variables (backend/.env)
| Var | Purpose |
|---|---|
| PORT | API port (default 5000) |
| MONGO_URI | MongoDB connection string |
| JWT_SECRET | Secret for signing tokens – **change in production** |
| JWT_EXPIRES_IN | Token lifetime (default 7d) |
| CLIENT_URL | Allowed CORS origin |

## Production build
`cd frontend && npm run build` → static files in `frontend/dist`. Set `VITE_API_URL` to your API URL at build time if hosted separately.
